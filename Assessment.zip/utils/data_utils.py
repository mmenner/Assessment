
import re
from sklearn.metrics import f1_score, confusion_matrix, recall_score, precision_score, roc_auc_score, accuracy_score
import numpy as np
import pandas as pd

def clf_get_performance(y_test, y_pred, purchase_value = []):
    cm = confusion_matrix(y_pred, y_test)
    try:
        performance = {
        'f1':np.round(f1_score(y_test, y_pred),3),
        'recall':np.round(recall_score(y_test, y_pred),3),
        'precision':np.round(precision_score(y_test, y_pred),3),
        'accuracy':np.round(accuracy_score(y_test, y_pred),3),
        'roc_auc':np.round(roc_auc_score(y_test, y_pred),3),
        'tn': cm[0][0],
        'tp':cm[1][1],
        'fn':cm[0][1],
        'fp':cm[1][0],
        'tnr': np.round(cm[0][0]/sum(sum(cm)),3),
        'tpr':np.round(cm[1][1]/sum(sum(cm)),3),
        'fnr': np.round(cm[0][1]/sum(sum(cm)),3),
        'fpr': np.round(cm[1][0]/sum(sum(cm)),3),
        'pr_data': np.round((cm[1][1]+cm[0][1])/sum(sum(cm)),3),
        'nr_data': np.round((cm[0][0]+cm[1][0])/sum(sum(cm)),3),
        }
    except:
        performance = {
            'f1':np.round(f1_score(y_test, y_pred),3),
            'recall':np.round(recall_score(y_test, y_pred),3),
            'precision':np.round(precision_score(y_test, y_pred),3),
            'accuracy':np.round(accuracy_score(y_test, y_pred),3),
            'fp': sum((y_test == 0)*(y_pred == 1)*1),
            'fn': sum((y_test == 1)*(y_pred == 0)*1),
            'tp': sum((y_test == 1)*(y_pred == 1)*1),
            'tn': sum((y_test == 0)*(y_pred == 0)*1)
        }
    if len(purchase_value) > 0:
        performance['Electronica_cost'] = sum((y_test == 0)*(y_pred == 1)*1)*8 + sum(purchase_value*(y_test == 1)*(y_pred == 0)*1)
    return performance


#function to assign each ip address in use to a country (missing countries are assigned as 'Other' by default)
def get_country(df, df_ip_to_c, missing = 'Other'):
    #iterating unique ip addresses. Takes some time. Iterating over bounds instead may help a bit in performance but after trying not much difference
    #Long term efficient approach would be to create mapping hash table
    unique_ip_addresses = np.unique(df.ip_address.values)
    dict_ip = {} 
    for v in unique_ip_addresses:
        idx = np.where((v >= df_ip_to_c.lower_bound_ip_address) &  (v <= df_ip_to_c.upper_bound_ip_address))[0]
        if len(idx) == 0:
            dict_ip[v] = missing
        else:
            dict_ip[v] = df_ip_to_c.loc[idx[0]].country
    df_ip = pd.DataFrame(data = {'ip_address' : dict_ip.keys(), 'country' : dict_ip.values()})
    return df_ip


def get_and_assign_country(df_fraud, df_ip_to_c, fill_missing_country = 'Other'):
    #assign country to ip address 
    df_ip = get_country(df_fraud, df_ip_to_c, fill_missing_country)
    df_ip['country'] = clean_special_char(df_ip.country.values)
    df_fraud['ip_address'] = df_fraud.ip_address.astype(int)
    df_fraud = df_fraud.merge(df_ip, how = 'left', on = 'ip_address')
    return df_fraud, df_ip


#to clean fields for one hot encoding in order to have valid column names
def clean_special_char(texts):
    clean_text = []
    for text in texts:
        clean_text.append(re.sub(r'[^a-zA-Z0-9\s]', '', text).replace(' ', '_'))
    return clean_text


#below make sure that features for scoring are the same as features used for modeling. One hot encoding e.g. can lead to additional / missing columns.
#additional columns are removed (column handling could be improved by additional residual columns), 
#missing columns are added with values of 0 (valid since all affecteed columns come from one hot encoded features).
def adjust_to_train_df(df, columns):
    df_columns = df.columns
    for col in columns:
        if col not in df_columns:
            df[col] = 0
    for df_col in df_columns:
        if df_col not in columns:
            df_col = df_col.drop(columns = [df_col])
    return df[columns]


#function to encode features
def one_hot_encodings(df, fields, drop_first = False):
    for field in fields:
        #one could additionally drop the first (multi-collinear), but effect small and as such easier with the current handling for scoring
        df = pd.concat([df, pd.get_dummies(df[field], prefix=field, drop_first=drop_first)*1], axis = 1)
        df = df.drop(columns = [field])
    return df


#feature class to perform feature engineering fr training and scoring data
class FeaturePrep:
    def __init__(self, df_fraud, df_ip_to_c, ohe_columns,train_columns = None, frequent_countries = None, is_scoring=False) -> None:
        self.df_fraud = df_fraud.fillna(0)
        self.df_ip_to_c = df_ip_to_c.fillna(0)
        self.n = len(df_fraud)
        self.ohe_columns = ohe_columns
        self.is_scoring = is_scoring
        self.frequent_countries = frequent_countries
        self.train_columns = train_columns
    
    #performs feature engineering (see MVP in modeling.ipynb and comments on the way)
    def get_features(self):
        self.df_fraud, _ = get_and_assign_country(self.df_fraud, self.df_ip_to_c)
        if self.is_scoring == False:
            self.frequent_countries = self.df_fraud[['country','user_id']].groupby('country').count().reset_index().sort_values('user_id', ascending = False).country[:30].values
        self.df_fraud['country'] = [val if val in self.frequent_countries else 'Other' for val in self.df_fraud.country]
        self.df_fraud = one_hot_encodings(self.df_fraud, self.ohe_columns, drop_first=False)
        self.df_fraud['purchase_time'] = pd.to_datetime(self.df_fraud['purchase_time']) 
        self.df_fraud['signup_time'] = pd.to_datetime(self.df_fraud['signup_time'])
        self.df_fraud['instant_purchase'] = ((self.df_fraud['purchase_time'] - self.df_fraud['signup_time']).dt.seconds < 10)*1
        self.df_fraud['month_signup'] = [val.month for val in self.df_fraud.signup_time]
        self.df_fraud['month_purchase'] = [val.month for val in self.df_fraud.purchase_time]
        self.df_fraud = self.df_fraud.drop(columns = ['signup_time', 'purchase_time', 'device_id'])
        self.df_fraud = self.df_fraud.set_index('user_id')
        if 'class' in self.df_fraud.columns:
            self.y = self.df_fraud['class']
            self.X = self.df_fraud.drop(columns = ['class'])
        else:
            self.X = self.df_fraud
        if self.is_scoring == False:
            self.fraud_ip_address = np.unique(self.X[self.y==1].ip_address)
        drop_cols = ['ip_address']
        self.X = self.X.drop(columns = drop_cols)
        if self.is_scoring:
            self.X = adjust_to_train_df(self.X,columns = self.train_columns)